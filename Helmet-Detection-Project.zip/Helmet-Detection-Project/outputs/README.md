Place genuine annotated prediction images/videos here after running the scripts. No fabricated result images are included in this archive.

Generated outputs are ignored by Git by default to avoid accidentally committing large files. If you want to showcase selected results, remove the relevant ignore rule or force-add only those small, genuine examples.
